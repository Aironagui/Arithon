ARITHON ANDROID PROJECT

This is an Android Studio project that packages the current Arithon HTML/CSS/JavaScript prototype inside an Android WebView. The HTML is bundled in app/src/main/assets/index.html, so the game interface itself does not need GitHub Pages or an internet connection to open. The game uses localStorage for progress/settings.

IMPORTANT: This is the Android project source, not a compiled APK yet. Building the APK requires Android Studio and the Android SDK/Gradle dependencies.

HOW TO BUILD A DEBUG APK
1. On a computer, install Android Studio (official site: https://developer.android.com/studio).
2. Extract the Arithon_Android_Project.zip.
3. In Android Studio choose Open and select the extracted Arithon_Android_Project folder (the folder containing settings.gradle).
4. Allow Gradle sync and install any SDK components Android Studio requests. Internet is needed for the first sync/build.
5. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
6. When complete, use the notification's Locate link. The debug APK is normally at app/build/outputs/apk/debug/app-debug.apk.
7. Transfer the APK to your Android phone and install it. Android may ask permission to install apps from that file manager; only install your own trusted build.

OFFLINE NOTE
The prototype HTML/CSS/JavaScript is bundled locally, so the main game can launch offline. Any features that explicitly depend on external websites or remote resources would still require internet; test airplane mode before using it for research. This project has not been compiled or device-tested in this environment.

PACKAGE
App label: Arithon
Application ID: com.aironagui.arithon
Version: 1.0
Minimum Android: Android 6.0 (API 23)
